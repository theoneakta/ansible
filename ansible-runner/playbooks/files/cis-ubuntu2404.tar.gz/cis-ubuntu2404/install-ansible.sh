#!/bin/bash
# Installs ansible-core >= 2.16 (what the CIS roles need) - needs package/PyPI access ONCE.
# Uses the distro package when it is new enough, otherwise a private venv in ./venv.
set -euo pipefail
cd "$(dirname "$0")"
need="2.16"
ver_ok() { [ "$(printf '%s\n%s\n' "$need" "$1" | sort -V | head -1)" = "$need" ]; }
have() { ansible --version 2>/dev/null | head -1 | grep -oE '[0-9]+\.[0-9]+(\.[0-9]+)?' | head -1; }
SUDO=""; [ "$(id -u)" -ne 0 ] && SUDO="sudo"
. /etc/os-release
echo "OS: $PRETTY_NAME"
if [ -x ./venv/bin/ansible-playbook ]; then echo "ansible already in ./venv: $(./venv/bin/ansible --version | head -1)"; exit 0; fi
if v=$(have) && [ -n "$v" ] && ver_ok "$v"; then echo "ansible-core $v already installed"; exit 0; fi
case "$ID ${ID_LIKE:-}" in
  *rhel*|*fedora*|*centos*|*rocky*|*almalinux*)
    $SUDO dnf -y install ansible-core python3 tar >/dev/null 2>&1 || true ;;
  *debian*|*ubuntu*)
    $SUDO apt-get update -qq && $SUDO apt-get install -y -qq ansible-core python3 python3-venv >/dev/null 2>&1 || true ;;
esac
if v=$(have) && [ -n "$v" ] && ver_ok "$v"; then echo "installed ansible-core $v (distro package)"; exit 0; fi
echo "distro ansible-core is missing or older than $need - installing a private copy in ./venv"
PY=""
for p in python3.13 python3.12 python3.11 python3.10 python3; do
  command -v $p >/dev/null && $p -c 'import sys; sys.exit(0 if sys.version_info >= (3,10) else 1)' && { PY=$p; break; }
done
if [ -z "$PY" ]; then
  case "$ID ${ID_LIKE:-}" in
    *rhel*|*fedora*|*centos*|*rocky*|*almalinux*) $SUDO dnf -y install python3.12 python3.12-pip && PY=python3.12 ;;
    *) echo "ERROR: ansible-core $need needs Python 3.10+ (this system has $(python3 --version 2>&1))."; exit 1 ;;
  esac
fi
$PY -m venv ./venv
./venv/bin/pip install -q --upgrade pip
./venv/bin/pip install -q "ansible-core>=2.16,<2.20"
echo "installed $(./venv/bin/ansible --version | head -1) in ./venv"
