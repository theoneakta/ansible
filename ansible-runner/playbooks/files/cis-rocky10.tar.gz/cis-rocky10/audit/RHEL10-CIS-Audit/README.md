
# RHEL 10 Syver config

## Overview

Based on RHEL 10 CIS 1.0.1 - 22-Sep-2025

Ability to audit a system using a lightweight binary to check the current state.

### Memory Usage
 Running the audit sees an Increased RAM usage, improvements seen when dropping swappiness e.g. 5. Already improved by latest kernel update 6.12.0-55.12.1 as of 19-05-25

This is:

- very small
- lightweight
- self contained

It works using a set of configuration files and directories to audit CIS of RHEL family 10 servers. These files/directories correlate to the CIS Level and CIS_ID

Tested on

- RHEL10
- almalinux10
- rocky10

## Requirements

You must have [syver](https://github.com/krameff/syver) >= 0.13.0 available to your host you would like to test. The audit
content uses the goss file format, which syver reads unchanged.

Syver replaces goss as it is a signed fork that is regularly updated.

You must have sudo/root access to the system as some commands require privilege information.

Assuming you have already cloned this repository you can run syver from where you wish.

Please refer to the audit documentation for usage.

- [readthedocs](https://ansible-lockdown.readthedocs.io/en/latest/)

This also works alongside the [Ansible Lockdown RHEL10-CIS role](https://github.com/ansible-lockdown/RHEL10-CIS)

Which will:

- install
- audit
- remediate
- audit

## Join us

On our [Discord Server](https://www.lockdownenterprise.com/discord) to ask questions, discuss features, or just chat with other Ansible-Lockdown users

## Contributing

Bug reports and feature requests are welcome from everyone, please raise an issue.

Pull requests are accepted from approved contributors. To be onboarded, join the [Discord Server](https://www.lockdownenterprise.com/discord) and request contributor access. See [CONTRIBUTING.md](CONTRIBUTING.md) for the full process.

Set of configuration files and directories to run the first stages of CIS of RHEL 10 servers

This is configured in a directory structure level.

Syver is run based on the goss.yml file in the top level directory. This specifies the configuration.

## Further Information

- [Syver documentation](https://github.com/krameff/syver/blob/main/docs/index.md)
- [goss vs Syver](https://github.com/krameff/syver/blob/main/docs/goss-vs-syver.md)
- [CIS standards](https://www.cisecurity.org)
