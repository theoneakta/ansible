# Copyright (c) Ansible project
# GNU General Public License v3.0+ (see LICENSES/GPL-3.0-or-later.txt or https://www.gnu.org/licenses/gpl-3.0.txt)
# SPDX-License-Identifier: GPL-3.0-or-later

# Note that this doc fragment is **PRIVATE** to the collection. It can have breaking changes at any time.
# Do not use this from other collections or standalone plugins/modules!

from __future__ import annotations


class ModuleDocFragment:
    # Standard files documentation fragment
    DOCUMENTATION = r"""
options:
  api_url:
    description:
      - The resolvable endpoint for the API.
    type: str
  api_username:
    description:
      - The username to use for authentication against the API.
    type: str
  api_password:
    description:
      - The password to use for authentication against the API.
    type: str
  validate_certs:
    description:
      - Whether or not to validate SSL certs when supplying a HTTPS endpoint.
    type: bool
    default: true
"""
